import{a}from"./chunk-CXR7PZZF.js";import"./chunk-EQDQRRRY.js";export{a as BLOG_POSTS};
